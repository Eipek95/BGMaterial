﻿namespace BGMaterial.Application.Interfaces
{
    public interface IService
    {
    }
}
