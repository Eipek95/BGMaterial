﻿namespace BGMaterial.Application.Features.Mediator.Results
{
    public class GetCheckAppUserQueryResult
    {
        public int Id { get; set; }
        public string Username { get; set; }
    }
}
