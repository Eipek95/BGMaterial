﻿namespace BGMaterial.Application.Tools
{
    public class JwtTokenDefaults
    {
        public const string ValidAudience = "https:\\localhost";
        public const string ValidIssuer = "https:\\localhost";
        public const string Key = "BGMat5/ZZQhA5qypzuuXHDswV2XsI4lUMqq3TB/LZ/bI=";
        public const int Expire = 5; // dk
    }
}
