﻿namespace BGMaterial.Application.Dtos
{
    public class NoContentDto
    {
    }
}
