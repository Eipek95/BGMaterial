﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BGMaterial.Persistence.Migrations
{
    /// <inheritdoc />
    public partial class init2 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "MaterialNumber",
                table: "Materials",
                newName: "Code");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "Code",
                table: "Materials",
                newName: "MaterialNumber");
        }
    }
}
